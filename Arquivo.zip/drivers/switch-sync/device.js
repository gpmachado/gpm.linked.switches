'use strict';

const { Device } = require('homey');

class SwitchSyncDevice extends Device {

  async onInit() {
    this.log(`[${this.getName()}] Initialized`);

    // deviceId → { device, onoffInstance }
    this._listeners = new Map();
    this._deviceNames = new Map();

    // Echo suppression: deviceId → { value, timer }
    this._suppress = new Map();

    this.registerCapabilityListener('onoff', this._onOwnOnOff.bind(this));

    await this._subscribeToDevices();
  }

  async reloadConfiguration() {
    this.log(`[${this.getName()}] Reloading configuration...`);
    await this._subscribeToDevices();
  }

  async _api() {
    return this.homey.app.getHomeyAPI();
  }

  // ─── Subscribe ────────────────────────────────────────────────────────────

  async _subscribeToDevices() {
    // Tear down existing capability instances
    for (const { onoffInstance } of this._listeners.values()) {
      try { onoffInstance.destroy(); } catch (_) {}
    }
    this._listeners.clear();
    this._deviceNames.clear();

    const deviceIds = this.getStoreValue('deviceIds') || [];
    const api = await this._api();

    for (const deviceId of deviceIds) {
      try {
        const device = await api.devices.getDevice({ id: deviceId });
        const name = device.name;
        this._deviceNames.set(deviceId, name);

        // makeCapabilityInstance is the documented way to receive real-time
        // capability updates from devices managed by other apps
        const onoffInstance = device.makeCapabilityInstance('onoff', value => {
          this._onLinkedDeviceChanged(deviceId, name, value)
            .catch(err => this.error(`[${this.getName()}] Error handling change from "${name}": ${err.message}`));
        });

        this._listeners.set(deviceId, { device, onoffInstance });
        this.log(`[${this.getName()}] Subscribed to "${name}"`);
      } catch (err) {
        this.error(`[${this.getName()}] Could not subscribe "${deviceId}": ${err.message}`);
      }
    }

    await this._syncSubCapabilities(deviceIds);

    try {
      const namesStr = Array.from(this._deviceNames.values()).join('\n') || 'None';
      await this.setSettings({ linked_devices_info: namesStr });
    } catch (err) {
      this.error(`Failed to update settings: ${err.message}`);
    }

    // Boot sync — use onoffInstance.value (live state, not stale snapshot)
    try {
      let isAnyOn = false;
      for (const { onoffInstance } of this._listeners.values()) {
        if (onoffInstance.value === true) { isAnyOn = true; break; }
      }
      const virtualCurrent = this.getCapabilityValue('onoff');
      if (virtualCurrent !== isAnyOn) {
        if (this.getSetting('debug')) this.log(`[${this.getName()}] Boot sync: → ${isAnyOn}`);
        await this.setCapabilityValue('onoff', isAnyOn).catch(this.error);
      }
    } catch (err) {
      this.error(`[${this.getName()}] Boot sync error:`, err);
    }
  }

  // ─── Sub-capabilities (device names on card) ──────────────────────────────

  async _syncSubCapabilities(deviceIds) {
    const needed = new Set(deviceIds.map((_, i) => `linked_switch.${i + 1}`));

    for (const cap of this.getCapabilities()) {
      const isOldOnoff      = cap !== 'onoff' && cap.startsWith('onoff.');
      const isStale         = cap.startsWith('linked_switch.') && !needed.has(cap);
      const isOldDevStatus  = cap.startsWith('device_status.');
      if (isOldOnoff || isStale || isOldDevStatus) {
        await this.removeCapability(cap).catch(() => {});
      }
    }

    for (let i = 0; i < deviceIds.length; i++) {
      const capId = `linked_switch.${i + 1}`;
      const name  = this._deviceNames.get(deviceIds[i]) || deviceIds[i];
      try {
        if (!this.hasCapability(capId)) await this.addCapability(capId);
        await this.setCapabilityOptions(capId, { title: { en: 'Switch' } });
        await this.setCapabilityValue(capId, name);
      } catch (err) {
        this.error(`[${this.getName()}] Could not set up ${capId}: ${err.message}`);
      }
    }
  }

  // ─── Incoming: linked device changed (physical or remote) ─────────────────

  async _onLinkedDeviceChanged(sourceId, sourceName, value) {
    const isDebug = this.getSetting('debug');

    const suppressed = this._suppress.get(sourceId);
    if (suppressed && suppressed.value === value) {
      if (isDebug) this.log(`[${this.getName()}] Echo suppressed from "${sourceName}" (${value})`);
      return;
    }

    if (isDebug) this.log(`[${this.getName()}] "${sourceName}" → ${value ? 'ON' : 'OFF'}`);

    const current = this.getCapabilityValue('onoff');
    if (current !== value) await this.setCapabilityValue('onoff', value).catch(this.error);

    await this._propagate(value, sourceId);
  }

  // ─── Incoming: virtual device toggled via UI / Flow ───────────────────────

  async _onOwnOnOff(value) {
    this.log(`[${this.getName()}] Binding set to ${value ? 'ON' : 'OFF'} via UI/Flow`);
    await this._propagate(value, null);
  }

  // ─── Propagate to all linked devices (parallel) ───────────────────────────

  async _propagate(value, sourceId) {
    const deviceIds  = this.getStoreValue('deviceIds') || [];
    const suppressMs = this.getSetting('suppress_ms') || 2000;
    const isDebug    = this.getSetting('debug');

    const promises = deviceIds.map(async (deviceId) => {
      if (deviceId === sourceId) return;

      const entry = this._listeners.get(deviceId);
      if (!entry) return;

      const { device, onoffInstance } = entry;

      if (!device.available) {
        if (isDebug) this.log(`[${this.getName()}] Skipping unavailable "${device.name}"`);
        return;
      }

      // Read live state from the capability instance (not stale capabilitiesObj snapshot)
      const current = onoffInstance.value;
      if (current === value) {
        if (isDebug) this.log(`[${this.getName()}] "${device.name}" already ${value ? 'ON' : 'OFF'} — skipped`);
        return;
      }

      const existing = this._suppress.get(deviceId);
      if (existing) this.homey.clearTimeout(existing.timer);
      const timer = this.homey.setTimeout(() => this._suppress.delete(deviceId), suppressMs);
      this._suppress.set(deviceId, { value, timer });

      if (isDebug) this.log(`[${this.getName()}] → ${value ? 'ON' : 'OFF'} to "${device.name}"`);

      return device.setCapabilityValue({ capabilityId: 'onoff', value });
    });

    const results = await Promise.allSettled(promises);
    results.forEach((r, i) => {
      if (r.status === 'rejected') {
        const name = this._deviceNames.get(deviceIds[i]) || deviceIds[i];
        this.error(`[${this.getName()}] Failed to set "${name}": ${r.reason?.message || r.reason}`);
      }
    });
  }

  // ─── Settings changed ─────────────────────────────────────────────────────

  async onSettings({ changedKeys }) {
    this.log(`[${this.getName()}] Settings changed: ${changedKeys.join(', ')}`);
  }

  // ─── Cleanup ──────────────────────────────────────────────────────────────

  async onDeleted() {
    this.log(`[${this.getName()}] Deleted — cleaning up`);
    for (const { onoffInstance } of this._listeners.values()) {
      try { onoffInstance.destroy(); } catch (_) {}
    }
    this._listeners.clear();
    for (const { timer } of this._suppress.values()) this.homey.clearTimeout(timer);
    this._suppress.clear();
  }

}

module.exports = SwitchSyncDevice;
